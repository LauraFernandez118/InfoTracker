package org.junit.jupiter;


import com.google.gson.*;
import java.sql.*;
import java.util.*;
import java.util.concurrent.locks.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.logging.Logger;

public class EventStoreService {
    private static final Logger logger = Logger.getLogger(EventStoreService.class.getName());
    private final String dbPath;
    private final ReentrantLock dbLock = new ReentrantLock();
    private Connection connection;

    static {
        try {
            Class.forName("org.sqlite.JDBC");
        } catch (ClassNotFoundException e) {
            throw new RuntimeException("SQLite JDBC driver not found", e);
        }
    }

    public EventStoreService(String dbPath, String brokerUrl) {
        this.dbPath = dbPath;
        initializeDatabase();
    }

    private synchronized Connection getConnection() throws SQLException {
        if (connection == null || connection.isClosed()) {
            connection = DriverManager.getConnection("jdbc:sqlite:" + dbPath);
            connection.setAutoCommit(false);
        }
        return connection;
    }

    private void initializeDatabase() {
        dbLock.lock();
        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement()) {

            // Tabla principal de eventos
            stmt.execute("""
                CREATE TABLE IF NOT EXISTS unified_events (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    event_type TEXT NOT NULL CHECK(event_type IN ('news', 'video')),
                    source_system TEXT NOT NULL,
                    topic TEXT NOT NULL,
                    title TEXT NOT NULL,
                    source_channel TEXT,
                    published_at TEXT,
                    url TEXT UNIQUE,
                    content_json TEXT NOT NULL,
                    stored_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    processed BOOLEAN DEFAULT FALSE
                )""");

            // Tabla de metadatos
            stmt.execute("""
                CREATE TABLE IF NOT EXISTS event_metadata (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    event_id INTEGER NOT NULL,
                    processed_at TIMESTAMP,
                    processing_status TEXT,
                    FOREIGN KEY (event_id) REFERENCES unified_events(id) ON DELETE CASCADE
                )""");

            // Índices
            stmt.execute("""
                CREATE INDEX IF NOT EXISTS idx_events_type ON unified_events(event_type)""");
            stmt.execute("""
                CREATE INDEX IF NOT EXISTS idx_events_topic ON unified_events(topic)""");
            stmt.execute("""
                CREATE INDEX IF NOT EXISTS idx_events_processed ON unified_events(processed)""");

            conn.commit();
            logger.info("Database initialized successfully");
        } catch (SQLException e) {
            logger.severe("Error initializing database: " + e.getMessage());
            throw new RuntimeException("Database initialization failed", e);
        } finally {
            dbLock.unlock();
        }
    }

    public void saveNewsEvent(String topic, JsonObject newsJson) {
        if (!newsJson.has("articles")) {
            logger.warning("Invalid news JSON format - missing 'articles' array");
            throw new IllegalArgumentException("Invalid news JSON format");
        }
        saveEvents("news", "newsapi", topic, newsJson.getAsJsonArray("articles"));
    }

    public void saveVideoEvent(String topic, JsonObject videoJson) {
        if (!videoJson.has("items")) {
            logger.warning("Invalid video JSON format - missing 'items' array");
            throw new IllegalArgumentException("Invalid video JSON format");
        }
        saveEvents("video", "youtube", topic, videoJson.getAsJsonArray("items"));
    }

    private void saveEvents(String eventType, String sourceSystem, String topic, JsonArray items) {
        dbLock.lock();
        try (Connection conn = getConnection()) {
            String eventSql = """
                INSERT OR IGNORE INTO unified_events 
                (event_type, source_system, topic, title, source_channel, published_at, url, content_json)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)""";

            String metaSql = """
                INSERT INTO event_metadata (event_id, processing_status)
                VALUES (?, 'PENDING')""";

            PreparedStatement eventStmt = conn.prepareStatement(eventSql, Statement.RETURN_GENERATED_KEYS);
            PreparedStatement metaStmt = conn.prepareStatement(metaSql);

            for (JsonElement item : items) {
                JsonObject obj = item.getAsJsonObject();
                EventData eventData = extractEventData(eventType, obj);

                // Insertar evento
                eventStmt.setString(1, eventType);
                eventStmt.setString(2, sourceSystem);
                eventStmt.setString(3, topic);
                eventStmt.setString(4, eventData.title());
                eventStmt.setString(5, eventData.sourceChannel());
                eventStmt.setString(6, eventData.publishedAt());
                eventStmt.setString(7, eventData.url());
                eventStmt.setString(8, obj.toString());
                eventStmt.executeUpdate();

                // Obtener ID generado y registrar metadatos
                try (ResultSet rs = eventStmt.getGeneratedKeys()) {
                    if (rs.next()) {
                        metaStmt.setInt(1, rs.getInt(1));
                        metaStmt.addBatch();
                    }
                }
            }

            metaStmt.executeBatch();
            conn.commit();
            logger.info("Saved " + items.size() + " " + eventType + " events for topic: " + topic);
        } catch (SQLException e) {
            logger.severe("Error saving events: " + e.getMessage());
            rollbackConnection();
            throw new RuntimeException("Failed to save events", e);
        } finally {
            dbLock.unlock();
        }
    }

    private EventData extractEventData(String eventType, JsonObject data) {
        String title = data.has("title") ? data.get("title").getAsString() : "";
        String sourceChannel = "";
        String publishedAt = "";
        String url = "";

        if (eventType.equals("news")) {
            JsonObject source = data.getAsJsonObject("source");
            sourceChannel = source.has("name") ? source.get("name").getAsString() : "unknown";
            publishedAt = data.has("publishedAt") ? data.get("publishedAt").getAsString() : "";
            url = data.has("url") ? data.get("url").getAsString() : "";
        } else if (eventType.equals("video")) {
            JsonObject snippet = data.getAsJsonObject("snippet");
            sourceChannel = snippet.has("channelTitle") ? snippet.get("channelTitle").getAsString() : "unknown";
            publishedAt = snippet.has("publishedAt") ? snippet.get("publishedAt").getAsString() : "";

            JsonObject idObj = data.getAsJsonObject("id");
            String videoId = idObj.has("videoId") ? idObj.get("videoId").getAsString() : "";
            url = "https://youtube.com/watch?v=" + videoId;
        }

        return new EventData(title, sourceChannel, publishedAt, url);
    }

    public List<JsonObject> getUnprocessedEvents() {
        dbLock.lock();
        List<JsonObject> events = new ArrayList<>();

        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("""
                 SELECT content_json FROM unified_events 
                 WHERE processed = FALSE
                 ORDER BY stored_at ASC""")) {

            while (rs.next()) {
                events.add(JsonParser.parseString(rs.getString("content_json")).getAsJsonObject());
            }

            if (!events.isEmpty()) {
                markEventsAsProcessed(conn);
            }

            conn.commit();
            logger.info("Retrieved " + events.size() + " unprocessed events");
            return events;
        } catch (Exception e) {
            logger.severe("Error retrieving unprocessed events: " + e.getMessage());
            rollbackConnection();
            throw new RuntimeException("Failed to get unprocessed events", e);
        } finally {
            dbLock.unlock();
        }
    }

    private void markEventsAsProcessed(Connection conn) throws SQLException {
        try (Statement stmt = conn.createStatement()) {
            stmt.executeUpdate("""
                UPDATE unified_events SET processed = TRUE 
                WHERE processed = FALSE""");

            stmt.executeUpdate("""
                UPDATE event_metadata SET 
                processed_at = CURRENT_TIMESTAMP,
                processing_status = 'PROCESSED'
                WHERE event_id IN (
                    SELECT id FROM unified_events 
                    WHERE processed = TRUE
                )""");
        }
    }

    public List<JsonObject> getEventsByTopic(String topic, int limit) {
        dbLock.lock();
        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement("""
                 SELECT content_json FROM unified_events 
                 WHERE topic = ? 
                 ORDER BY published_at DESC
                 LIMIT ?""")) {

            pstmt.setString(1, topic);
            pstmt.setInt(2, limit);

            List<JsonObject> events = new ArrayList<>();
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    events.add(JsonParser.parseString(rs.getString("content_json")).getAsJsonObject());
                }
            }

            conn.commit();
            return events;
        } catch (Exception e) {
            logger.severe("Error getting events by topic: " + e.getMessage());
            rollbackConnection();
            throw new RuntimeException("Failed to get events by topic", e);
        } finally {
            dbLock.unlock();
        }
    }

    public int cleanupOldEvents(int daysToKeep) {
        dbLock.lock();
        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement("""
                 DELETE FROM unified_events 
                 WHERE julianday('now') - julianday(stored_at) > ?
                 AND processed = TRUE""")) {

            pstmt.setInt(1, daysToKeep);
            int deleted = pstmt.executeUpdate();
            conn.commit();
            logger.info("Deleted " + deleted + " old events");
            return deleted;
        } catch (SQLException e) {
            logger.severe("Error cleaning old events: " + e.getMessage());
            rollbackConnection();
            throw new RuntimeException("Failed to clean old events", e);
        } finally {
            dbLock.unlock();
        }
    }

    private void rollbackConnection() {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.rollback();
            }
        } catch (SQLException e) {
            logger.severe("Error during rollback: " + e.getMessage());
        }
    }

    public void close() {
        dbLock.lock();
        try {
            if (connection != null && !connection.isClosed()) {
                connection.commit();
                connection.close();
            }
        } catch (SQLException e) {
            logger.severe("Error closing connection: " + e.getMessage());
        } finally {
            dbLock.unlock();
        }
    }

    // Record para almacenar datos de eventos temporalmente
    private record EventData(String title, String sourceChannel, String publishedAt, String url) {}
}