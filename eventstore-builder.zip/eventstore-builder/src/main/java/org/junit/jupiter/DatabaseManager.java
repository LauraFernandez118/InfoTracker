package org.junit.jupiter;

import java.sql.*;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class DatabaseManager {
    private final String dbPath;

    public DatabaseManager(String dbPath) {
        this.dbPath = dbPath;
        initializeDatabase();
    }

    private void initializeDatabase() {
        String sql = """
        PRAGMA foreign_keys = ON;
        
        CREATE TABLE IF NOT EXISTS unified_events (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            event_type TEXT NOT NULL CHECK(event_type IN ('news', 'video')),
            source_system TEXT NOT NULL,
            topic TEXT NOT NULL,
            title TEXT NOT NULL,
            source_channel TEXT,
            published_at TEXT,
            url TEXT UNIQUE,
            content_json TEXT NOT NULL,
            stored_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            processed BOOLEAN DEFAULT FALSE
        );
        
        CREATE TABLE IF NOT EXISTS event_metadata (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            event_id INTEGER NOT NULL,
            processed_at TIMESTAMP,
            processing_status TEXT,
            FOREIGN KEY (event_id) REFERENCES unified_events(id) ON DELETE CASCADE
        );
        
        CREATE INDEX IF NOT EXISTS idx_unified_events_type ON unified_events(event_type);
        CREATE INDEX IF NOT EXISTS idx_unified_events_topic ON unified_events(topic);
        CREATE INDEX IF NOT EXISTS idx_unified_events_processed ON unified_events(processed);
        """;

        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement()) {
            // Ejecutar cada sentencia por separado para mejor manejo de errores
            for (String statement : sql.split(";")) {
                if (!statement.trim().isEmpty()) {
                    stmt.execute(statement + ";");
                }
            }
        } catch (SQLException e) {
            System.err.println("Error initializing database: " + e.getMessage());
            throw new RuntimeException("Failed to initialize database", e);
        }
    }
    public Connection getConnection() throws SQLException {
        return DriverManager.getConnection("jdbc:sqlite:" + dbPath);
    }

    public void saveEvent(String eventType, String sourceSystem, String topic,
                          String title, String sourceChannel,
                          String publishedAt, String url, String jsonContent) {
        String sql = """
            INSERT OR IGNORE INTO events 
            (event_type, source_system, topic, title, source_channel, published_at, url, content_json)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """;

        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, eventType);
            pstmt.setString(2, sourceSystem);
            pstmt.setString(3, topic);
            pstmt.setString(4, title);
            pstmt.setString(5, sourceChannel);
            pstmt.setString(6, publishedAt);
            pstmt.setString(7, url);
            pstmt.setString(8, jsonContent);

            pstmt.executeUpdate();
        } catch (SQLException e) {
            System.err.println("Error saving event to database: " + e.getMessage());
        }
    }
}