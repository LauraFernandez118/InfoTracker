package org.junit.jupiter;

import java.sql.*;
import java.util.concurrent.locks.*;

public class DatabaseConnectionManager {
    private static DatabaseConnectionManager instance;
    private Connection connection;
    private final String dbPath;
    private final ReentrantLock lock = new ReentrantLock();

    private DatabaseConnectionManager(String dbPath) {
        this.dbPath = dbPath;
        initializeConnection();
    }

    public static synchronized DatabaseConnectionManager getInstance(String dbPath) {
        if (instance == null) {
            instance = new DatabaseConnectionManager(dbPath);
        }
        return instance;
    }

    private void initializeConnection() {
        try {
            Class.forName("org.sqlite.JDBC");
            this.connection = DriverManager.getConnection("jdbc:sqlite:" + dbPath);
            this.connection.setAutoCommit(false);
        } catch (Exception e) {
            throw new RuntimeException("Failed to initialize database connection", e);
        }
    }

    public Connection getConnection() {
        lock.lock();
        try {
            if (connection == null || connection.isClosed()) {
                initializeConnection();
            }
            return connection;
        } catch (SQLException e) {
            throw new RuntimeException("Failed to get database connection", e);
        } finally {
            lock.unlock();
        }
    }

    public void closeConnection() {
        lock.lock();
        try {
            if (connection != null && !connection.isClosed()) {
                connection.commit();
                connection.close();
            }
        } catch (SQLException e) {
            System.err.println("Error closing database connection: " + e.getMessage());
        } finally {
            lock.unlock();
        }
    }
}