package com.datascience;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public class Config {
    private final Map<String, String> params;

    public Config(String[] args) {
        this.params = parseArgs(args);
    }

    // Método para parsear los parámetros de la línea de comandos
    private Map<String, String> parseArgs(String[] args) {
        Map<String, String> params = new HashMap<>();
        Arrays.stream(args)
                .filter(arg -> arg.startsWith("--"))
                .forEach(arg -> {
                    String[] keyValue = arg.substring(2).split("=");
                    if (keyValue.length == 2) {
                        params.put(keyValue[0], keyValue[1]);
                    } else {
                        System.err.println("Parametro inválido: " + arg);
                    }
                });
        return params;
    }

    // Obtener la clave de API
    public String getApiKey() {
        return params.get("api-key");
    }

    // Obtener la ruta de la base de datos
    public String getDbPath() {
        return params.get("db-path");
    }

    // Obtener la palabra clave para la búsqueda
    public String getQueryKeyword() {
        return params.get("query-keyword");
    }

    // Método para verificar si todos los parámetros necesarios están presentes
    public boolean hasRequiredParams() {
        return getApiKey() != null && getDbPath() != null && getQueryKeyword() != null;
    }

    // Método de uso general para obtener parámetros si es necesario
    public String getParam(String key) {
        return params.get(key);
    }
}
