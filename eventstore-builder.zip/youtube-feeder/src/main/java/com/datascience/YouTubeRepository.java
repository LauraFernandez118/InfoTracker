package com.datascience;



import java.sql.*;

public class YouTubeRepository {
    private final String dbPath;

    public YouTubeRepository(String dbPath) {
        this.dbPath = dbPath;
        createTable();
    }

    private void createTable() {
        String sql = "CREATE TABLE IF NOT EXISTS youtube_videos (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "video_id TEXT UNIQUE," +  // ID único de YouTube
                "title TEXT," +
                "channel TEXT," +
                "published_at DATETIME," +
                "news_article_id INTEGER," + // Clave foránea
                "FOREIGN KEY (news_article_id) REFERENCES news_articles(id))";

        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:" + dbPath);
             Statement stmt = conn.createStatement()) {
            stmt.execute(sql);
        } catch (SQLException e) {
            System.err.println("Error al crear tabla de videos: " + e.getMessage());
        }
    }

    public void saveVideo(YouTubeVideo video) {
        String sql = "INSERT OR IGNORE INTO youtube_videos " +
                "(video_id, title, channel, published_at, news_article_id) VALUES (?, ?, ?, ?, ?)";

        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:" + dbPath);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, video.getVideoId());
            pstmt.setString(2, video.getTitle());
            pstmt.setString(3, video.getChannel());
            pstmt.setString(4, video.getPublishedAt());
            pstmt.setObject(5, video.getNewsArticleId(), Types.INTEGER);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            System.err.println("Error al guardar video: " + e.getMessage());
        }
    }
    public void save(YouTubeVideo article) throws SQLException {
        String sql = "INSERT INTO news_articles (title, source, published_at, url, query_keyword) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:" + dbPath);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, article.getTitle());
            pstmt.setString(2, article.getChannel());
            pstmt.setString(3, article.getPublishedAt());
            pstmt.setString(4, article.getUrl());
            pstmt.setString(5, article.getQueryKeyword());
            pstmt.executeUpdate();
        }
    }
    public boolean isNew(YouTubeVideo video) {
        String sql = "SELECT id FROM videos.db WHERE title = ? OR url = ?";
        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:" + dbPath);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, video.getTitle());
            pstmt.setString(2,  video.getUrl());
            return !pstmt.executeQuery().next();  // True si no existe
        } catch (SQLException e) {
            System.err.println("Error al verificar video: " + e.getMessage());
            return false;
        }
    }
}