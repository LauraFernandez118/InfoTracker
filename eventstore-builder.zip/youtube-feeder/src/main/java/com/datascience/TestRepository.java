package com.datascience;

public class TestRepository {
    public static void main(String[] args) {

        // Probar YouTubeRepository
        YouTubeRepository videoRepo = new YouTubeRepository("videos.db");
        YouTubeVideo video = new YouTubeVideo("abc123", "Video prueba", "Canal prueba", "2024-05-01");
        videoRepo.saveVideo(video);
        System.out.println("¿Es nuevo? " + videoRepo.isNew(video)); // Debe ser false
    }
}